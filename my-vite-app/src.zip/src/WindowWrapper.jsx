function WindowWrapper({ children }) {
    return (
      <div style={{
        backgroundColor: '#1f1f1f',
        borderRadius: '0',      // Remove rounded corners since it's full screen (optional)
        padding: '2rem',        // Keep padding or tweak as you want
        boxShadow: 'none',      // Remove shadow if you want a flat full-screen look
        width: '100vw',         // Full viewport width
        height: '100vh',        // Full viewport height
        color: 'white',
        overflowY: 'auto',      // Enable scrolling if content is taller than screen
        boxSizing: 'border-box' // Make padding count inside the width/height
      }}>
        {children}
      </div>
    );
  }
  